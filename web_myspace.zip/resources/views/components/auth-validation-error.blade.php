
@error($name)
    <small class="text-red-500 text-sm italic">{{ $message }}</small>
@enderror
