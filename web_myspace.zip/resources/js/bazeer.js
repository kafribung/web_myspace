import 'alpinejs';
