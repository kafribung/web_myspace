.<template>
    <div>
        <main class="mt-5 mb-10 px-10">
                <div class="flex justify-center items-center h-screen">
                    <div class="max-w-xl">
                        <div class="text-xl font-bold text-blue-400 mb-5">$4.0.4 Not Found</div>
                        <router-link :to="{name:'Home'}" class="text-9xl underline italic text-blue-400 mb-5">back to earth</router-link>
                    </div>
                </div>
        </main>
    </div>
</template>

<script>
export default {

}
</script>