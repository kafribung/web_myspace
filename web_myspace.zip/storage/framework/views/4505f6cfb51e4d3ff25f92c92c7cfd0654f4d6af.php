<div>
 <!-- Begin Page Content -->
 <div class="container-fluid" id="app">
    <?php if(session('msg')): ?>
        <p class="alert alert-info"><?php echo e(session('msg')); ?></p>
    <?php endif; ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">About <?php echo e(Auth::user()->name); ?></h1>
    </div>
    <!-- Content Row -->
    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-12 col-lg-11">
            <div class="card  shadow mb-4">
                <div class="card-header">
                    <a href=""  class="btn btn-primary btn-sm float-right"  data-toggle="modal" data-target="#addModal"><i class="fa fa-plus"></i></a>
                </div>
                <div class="card-body ">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">About</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $angkaAwal = 1
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <th scope="row"><?php echo e($angkaAwal++); ?></th>
                                <td><?php echo $about->description; ?></td>
                                <td>
                                    <a href="" wire:click="edit(<?php echo e($about->id); ?>)" class="btn btn-warning btn-sm"  data-toggle="modal" data-target="#editModal"><i class="fa fa-edit"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="alert alert-info">About Kosong</p>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php echo $__env->make('livewire.backend.about.about-create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('livewire.backend.about.about-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->startPush('after_script'); ?>
<script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('create').on('change', function(e){
        window.livewire.find('<?php echo e($_instance->id); ?>').set('description', e.editor.getData());
    });
</script>
<script>
    CKEDITOR.replace('edit').on('change', function(e){
        window.livewire.find('<?php echo e($_instance->id); ?>').set('description', e.editor.getData());
    });
</script>
<?php $__env->stopPush(); ?>
<!-- /.container-fluid -->
</div>
<?php /**PATH C:\Users\A C E R\Desktop\web_myspace\resources\views/livewire/backend/about/about.blade.php ENDPATH**/ ?>