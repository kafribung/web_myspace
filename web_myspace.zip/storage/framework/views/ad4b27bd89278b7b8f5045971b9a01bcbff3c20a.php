<div>
<!-- Begin Page Content -->
<div class="container-fluid" id="app">
    <?php if(session('msg')): ?>
        <p class="alert alert-info"><?php echo e(session('msg')); ?></p>
    <?php endif; ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">All Blog</h1>
    </div>
    <!-- Content Row -->
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4">
            <div class="card mb-4 py-3 border-left-success">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><?php echo e($blog->title); ?></h6>
                </div>
                <div class="card-body">
                    <p><?php echo Str::limit($blog->description, 30); ?></p>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <div>
                            <a href="<?php echo e(route('blog.edit', $blog)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                            <button  wire:click="delete(<?php echo e($blog->id); ?>)" id="delete" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                            <button  wire:click="active(<?php echo e($blog->id); ?>)" id="delete" class="btn <?php echo e($blog->active == 0 ? 'btn-info' : 'btn-dark'); ?>  btn-sm"><i class="fa <?php echo e($blog->active == 0 ? 'fa-check' : 'fa-minus'); ?>"></i></button>
                        </div>
                        <div>
                            <small><?php echo e($blog->user->name); ?></small>
                            <small><?php echo e($blog->created_at->diffForHumans()); ?></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="alert alert-success">Data Blog is Null</p>
        <?php endif; ?>
    </div>
</div>
<!-- /.container-fluid -->
</div>
<?php /**PATH C:\Users\A C E R\Desktop\web_myspace\resources\views/livewire/backend/blog/blog.blade.php ENDPATH**/ ?>