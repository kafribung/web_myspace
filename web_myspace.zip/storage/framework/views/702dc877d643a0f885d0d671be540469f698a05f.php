<div>
    <div class="form-group">
        <label for="title">Title</label>
        <input type="text" name="title" class="form-control"  value="<?php echo e($blog->title ?? old('title')); ?>" autocomplete="off" autofocus placeholder="input title" id="title">
        <?php if($errors->has('title')): ?>
            <p class="alert alert-danger"><?php echo e($errors->first('title')); ?></p>
        <?php endif; ?>
    </div>
    <div class="form-group" wire:ignore>
        <label for="description">description</label>
        <textarea  name="description"  id="description" class="form-control" placeholder="description"><?php echo e($blog->description ?? old('description')); ?></textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="alert alert-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button class="btn  <?php echo e($blog->title ? 'btn-warning' : 'btn-primary'); ?> float-right"><?php echo e($blog->title ? 'Edit' : 'Store'); ?></button>
    
</div><?php /**PATH C:\Users\A C E R\Desktop\web_myspace\resources\views/livewire/backend/blog/blog-form.blade.php ENDPATH**/ ?>