<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('dash/vendor/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('dash/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('dash/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('dash/js/sb-admin-2.min.js')); ?>"></script><?php /**PATH C:\Users\A C E R\Desktop\web_myspace\resources\views/includes/script_dash.blade.php ENDPATH**/ ?>