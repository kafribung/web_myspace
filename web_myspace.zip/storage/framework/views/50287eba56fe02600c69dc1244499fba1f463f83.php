
<?php $__env->startSection('title', 'Blog Create | min Kafri Bung Space'); ?>
<?php $__env->startSection('content'); ?>
 <!-- Begin Page Content -->
 <div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Create Blog</h1>
        <small><?php echo e($msg); ?></small>
    </div>
    <!-- Content Row -->
    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-12 col-lg-11">
            <div class="card shadow">
                <div class="card-body">
                    <form wire:submit.prevent="ok">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" name="title" class="form-control"  value="<?php echo e($blog->title ?? old('title')); ?>" autocomplete="off" autofocus placeholder="input title" id="title">
                            <?php if($errors->has('title')): ?>
                                <p class="alert alert-danger"><?php echo e($errors->first('title')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" id="description" class="form-control" placeholder="description"><?php echo e($blog->description ?? old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button class="btn  <?php echo e($blog ? 'btn-warning' : 'btn-primary'); ?> float-right"><?php echo e($blog ? 'Edit' : 'Store'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
<?php $__env->startPush('after_script'); ?>
<script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'description' );
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A C E R\Desktop\web_myspace\resources\views/livewire/backend/blog/create.blade.php ENDPATH**/ ?>