<div>
<!-- Begin Page Content -->
<div class="container-fluid" id="app">
    <?php if(session('msg')): ?>
        <p class="alert alert-info"><?php echo e(session('msg')); ?></p>
    <?php endif; ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Admin</h1>
    </div>
    <!-- Content Row -->
    <div class="row">
        <!-- Area Chart -->
        <div class="col-xl-12 col-lg-11">
            <div class="card  shadow mb-4">
                <div class="card-body ">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Email</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $angkaAwal = 1
                            ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($angkaAwal++); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <button data-toggle="modal" data-target="#updateModal"  wire:click="edit(<?php echo e($user->id); ?>)" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <?php echo $__env->make('livewire.backend.admin.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Logout Modal-->
</div>
</div>
<?php /**PATH C:\Users\A C E R\Desktop\web_myspace\resources\views/livewire/backend/admin/admin.blade.php ENDPATH**/ ?>