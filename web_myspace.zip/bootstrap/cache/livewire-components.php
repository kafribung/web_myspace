<?php return array (
  'backend.about' => 'App\\Http\\Livewire\\Backend\\About',
  'backend.admin' => 'App\\Http\\Livewire\\Backend\\Admin',
  'backend.blog' => 'App\\Http\\Livewire\\Backend\\Blog',
  'backend.dashboard' => 'App\\Http\\Livewire\\Backend\\Dashboard',
);